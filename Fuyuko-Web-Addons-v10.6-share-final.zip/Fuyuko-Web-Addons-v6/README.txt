Fuyuko Web Addons v5
- Supabase Auth + Postgres + Storage
- Username login tanpa Gmail UI
- Profile PNG upload
- Addon editor collapsed until Kelola/Update
- Multi category
- Version file history
- Threaded comments with collapsible replies
- Public/private requests + own request manager
- Public request search + supports + comments
- Admin request/user management
See README.md for setup.


Version 10.6: Share Addon button beside Simpan Rating + direct ?addon=ID links.
