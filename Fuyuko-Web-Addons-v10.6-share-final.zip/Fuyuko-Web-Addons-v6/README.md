# Fuyuko Web Addons — Final v6

Versi ini mempertahankan frontend HTML/CSS/JS terpisah dan memakai Supabase untuk Auth, database, RLS, dan Storage.

## Yang baru
- Fix query admin/request yang sebelumnya terkena `more than one relationship was found` dengan cara mengambil profiles terpisah.
- Users admin memakai daftar terpusat dan pencarian.
- Rating visual ★★★★★ mendukung 0.5.
- Input file dibuat custom agar tidak memakai tombol putih bawaan browser.
- Profile picture punya crop + zoom sebelum disimpan sebagai PNG.
- Admin bisa upload thumbnail addon dan file addon langsung dari website.
- Versi addon lama tetap disimpan.
- Report Bug dari menu hamburger, lengkap dengan screenshot.
- User bisa edit/hapus report miliknya sendiri.
- User bisa edit/hapus request miliknya sendiri.
- User bisa edit/hapus komentar addon dan komentar request miliknya sendiri.
- Menu Donate dengan URL Saweria yang dapat diatur admin.
- Admin dapat mencatat daftar donatur.
- Tombol close untuk modal/form utama dan UI mobile lebih rapi.
- Perlindungan status request/report agar user biasa tidak bisa mengganti status moderasi sendiri.

## Setup untuk project Supabase yang SUDAH dipakai
1. Jangan hapus tabel/database yang sudah ada.
2. Di Supabase SQL Editor, jalankan `supabase/final-migration.sql` satu kali.
3. Pastikan `supabase-config.js` berisi Project URL dan Publishable/anon key project kamu.
4. Refresh website.

## Setup dari awal
1. Jalankan `supabase/schema.sql`.
2. Jalankan `supabase/final-migration.sql`.
3. Register akun admin melalui website.
4. Jalankan `supabase/bootstrap-admin.sql` atau ubah username pada file tersebut dulu.
5. Upload folder ini ke GitHub Pages / jalankan lewat Acode Live Server.

## Storage yang dipakai
- `avatars` — foto profil.
- `request-files` — file referensi request, private.
- `addon-images` — thumbnail addon, public.
- `addon-files` — file addon, public.
- `bug-reports` — screenshot report, private.

## Addon upload
Di Admin → Addons, admin cukup memilih:
- Thumbnail langsung dari perangkat.
- File addon langsung dari perangkat.
- Versi addon.
- Versi Minecraft.
- Changelog.

Path GitHub lama tetap boleh dipakai di database untuk addon yang sudah ada. Upload baru akan menggunakan Supabase Storage.

## Donate
Admin → Donate → isi URL Saweria → Save Donation Link.
Data donor pada halaman admin adalah catatan donatur yang dimasukkan/ditandai admin. Integrasi transaksi otomatis Saweria tidak diasumsikan tersedia tanpa webhook/API yang memang aktif pada akun/layanan yang dipakai.

## Keamanan
- Jangan pernah memasukkan `service_role`/secret key ke frontend.
- Publishable/anon key memang digunakan di frontend.
- RLS harus tetap aktif.
- Password tetap dikelola oleh Supabase Auth.

## Download mode (v7)
Setiap file/versi addon punya dua pilihan metode download:
- `Download here`: admin upload file addon ke Supabase Storage. Tombol pengguna tampil `Download`.
- `From link`: admin memasukkan URL eksternal seperti MediaFire atau layanan safelink. Tombol pengguna tampil `Go to link` dan mengarahkan pengguna ke URL tersebut.

Jalankan `supabase/final-migration.sql` lagi satu kali setelah mengganti ke versi ini. Migration bersifat idempoten untuk kolom download baru.


Version 10.6: Share Addon button beside Simpan Rating + direct ?addon=ID links.
