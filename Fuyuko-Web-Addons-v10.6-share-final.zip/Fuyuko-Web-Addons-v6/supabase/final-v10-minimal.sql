-- Fuyuko Web Addons v10 minimal migration
-- Run this ONCE after v9. No schema reset required.

alter table public.site_settings add column if not exists categories jsonb not null default '[]'::jsonb;

-- Safe admin-only user deletion. Child data is cleaned first; addon ownership is reassigned to the current admin.
create or replace function public.admin_delete_user(p_user_id uuid)
returns void
language plpgsql
security definer
set search_path=public,auth
as $$
declare
  admin_id uuid := auth.uid();
begin
  if not public.is_admin() then raise exception 'Admin only'; end if;
  if p_user_id is null or p_user_id = admin_id then raise exception 'Tidak boleh menghapus akun admin yang sedang login.'; end if;
  if not exists(select 1 from public.profiles where id=p_user_id) then raise exception 'User tidak ditemukan.'; end if;

  update public.addons set created_by=admin_id, updated_at=now() where created_by=p_user_id;
  delete from public.request_supports where user_id=p_user_id;
  delete from public.request_comments where user_id=p_user_id;
  delete from public.requests where user_id=p_user_id;
  delete from public.comments where user_id=p_user_id;
  delete from public.ratings where user_id=p_user_id;
  delete from public.bug_reports where user_id=p_user_id;
  delete from public.donations where created_by=p_user_id;
  delete from auth.users where id=p_user_id;
end;
$$;

grant execute on function public.admin_delete_user(uuid) to authenticated;

-- Keep the existing public settings read policy and admin write policy from v9.
