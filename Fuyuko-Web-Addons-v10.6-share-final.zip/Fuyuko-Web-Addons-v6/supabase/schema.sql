-- Fuyuko Web Addons database
-- Run this in Supabase SQL Editor after creating your project.

create extension if not exists pgcrypto;

do $$ begin
  create type public.user_role as enum ('user','admin');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.request_visibility as enum ('private','public');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.request_status as enum ('pending','accepted','rejected');
exception when duplicate_object then null; end $$;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null unique,
  display_name text not null,
  avatar_url text,
  role public.user_role not null default 'user',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.addons (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text not null,
  tags text[] not null default '{}',
  image_path text not null,
  video_url text,
  author text not null default 'Fuyuko Team',
  features text[] not null default '{}',
  downloads bigint not null default 0,
  created_by uuid not null references public.profiles(id) on delete restrict,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.addon_releases (
  id uuid primary key default gen_random_uuid(),
  addon_id uuid not null references public.addons(id) on delete cascade,
  version text not null,
  mc_version text not null,
  file_path text not null,
  changelog text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.ratings (
  addon_id uuid not null references public.addons(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  rating numeric(2,1) not null check (rating >= .5 and rating <= 5 and mod((rating*10)::int,5)=0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  primary key (addon_id,user_id)
);

create table if not exists public.comments (
  id uuid primary key default gen_random_uuid(),
  addon_id uuid not null references public.addons(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  parent_id uuid references public.comments(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 4000),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 120),
  description text not null check (char_length(description) between 1 and 4000),
  visibility public.request_visibility not null default 'private',
  status public.request_status not null default 'pending',
  file_path text,
  file_name text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.request_supports (
  request_id uuid not null references public.requests(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (request_id,user_id)
);

create table if not exists public.request_comments (
  id uuid primary key default gen_random_uuid(),
  request_id uuid not null references public.requests(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  parent_id uuid references public.request_comments(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 4000),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_addons_updated_at on public.addons(updated_at desc);
create index if not exists idx_releases_addon on public.addon_releases(addon_id,created_at desc);
create index if not exists idx_comments_addon on public.comments(addon_id,created_at);
create index if not exists idx_requests_user on public.requests(user_id,created_at desc);
create index if not exists idx_requests_public on public.requests(visibility,created_at desc);
create index if not exists idx_request_comments on public.request_comments(request_id,created_at);

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path=public
as $$
begin
  insert into public.profiles(id,username,display_name)
  values(
    new.id,
    coalesce(new.raw_user_meta_data->>'username', split_part(new.email,'@',1)),
    coalesce(new.raw_user_meta_data->>'display_name', new.raw_user_meta_data->>'username', split_part(new.email,'@',1))
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.is_admin()
returns boolean
language sql
stable
security definer set search_path=public
as $$
  select exists(select 1 from public.profiles where id=auth.uid() and role='admin');
$$;

create or replace function public.set_user_role(p_user_id uuid,p_role public.user_role)
returns void
language plpgsql
security definer set search_path=public
as $$
begin
  if not public.is_admin() then raise exception 'Admin only'; end if;
  update public.profiles set role=p_role,updated_at=now() where id=p_user_id;
end;
$$;

grant execute on function public.set_user_role(uuid,public.user_role) to authenticated;

grant execute on function public.is_admin() to anon,authenticated;

create or replace function public.increment_download(p_addon_id uuid)
returns void
language sql
security definer set search_path=public
as $$
  update public.addons set downloads=downloads+1,updated_at=updated_at where id=p_addon_id;
$$;
grant execute on function public.increment_download(uuid) to anon,authenticated;

alter table public.profiles enable row level security;
alter table public.addons enable row level security;
alter table public.addon_releases enable row level security;
alter table public.ratings enable row level security;
alter table public.comments enable row level security;
alter table public.requests enable row level security;
alter table public.request_supports enable row level security;
alter table public.request_comments enable row level security;

-- Profiles
create policy profiles_select on public.profiles for select to authenticated using (id=auth.uid() or public.is_admin());
create policy profiles_update_self on public.profiles for update to authenticated using (id=auth.uid()) with check (id=auth.uid());

-- Addons
create policy addons_public_select on public.addons for select to anon,authenticated using (true);
create policy addons_admin_insert on public.addons for insert to authenticated with check (public.is_admin());
create policy addons_admin_update on public.addons for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy addons_admin_delete on public.addons for delete to authenticated using (public.is_admin());

-- Releases
create policy releases_public_select on public.addon_releases for select to anon,authenticated using (true);
create policy releases_admin_insert on public.addon_releases for insert to authenticated with check (public.is_admin());
create policy releases_admin_update on public.addon_releases for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy releases_admin_delete on public.addon_releases for delete to authenticated using (public.is_admin());

-- Ratings
create policy ratings_select on public.ratings for select to anon,authenticated using (true);
create policy ratings_insert_own on public.ratings for insert to authenticated with check (user_id=auth.uid());
create policy ratings_update_own on public.ratings for update to authenticated using (user_id=auth.uid()) with check (user_id=auth.uid());
create policy ratings_delete_own on public.ratings for delete to authenticated using (user_id=auth.uid());

-- Comments
create policy comments_select on public.comments for select to anon,authenticated using (true);
create policy comments_insert_auth on public.comments for insert to authenticated with check (user_id=auth.uid());
create policy comments_update_own on public.comments for update to authenticated using (user_id=auth.uid() or public.is_admin()) with check (user_id=auth.uid() or public.is_admin());
create policy comments_delete_own on public.comments for delete to authenticated using (user_id=auth.uid() or public.is_admin());

-- Requests: public OR own OR admin
create policy requests_select on public.requests for select to authenticated using (visibility='public' or user_id=auth.uid() or public.is_admin());
create policy requests_insert_own on public.requests for insert to authenticated with check (user_id=auth.uid());
create policy requests_update_own on public.requests for update to authenticated using (user_id=auth.uid() or public.is_admin()) with check (user_id=auth.uid() or public.is_admin());
create policy requests_delete_own on public.requests for delete to authenticated using (user_id=auth.uid() or public.is_admin());

create policy request_supports_select on public.request_supports for select to authenticated using (exists(select 1 from public.requests r where r.id=request_id and (r.visibility='public' or r.user_id=auth.uid() or public.is_admin())));
create policy request_supports_insert on public.request_supports for insert to authenticated with check (user_id=auth.uid() and exists(select 1 from public.requests r where r.id=request_id and r.visibility='public'));
create policy request_supports_delete on public.request_supports for delete to authenticated using (user_id=auth.uid());

create policy request_comments_select on public.request_comments for select to authenticated using (exists(select 1 from public.requests r where r.id=request_id and (r.visibility='public' or r.user_id=auth.uid() or public.is_admin())));
create policy request_comments_insert on public.request_comments for insert to authenticated with check (user_id=auth.uid() and exists(select 1 from public.requests r where r.id=request_id and (r.visibility='public' or r.user_id=auth.uid() or public.is_admin())));
create policy request_comments_update_own on public.request_comments for update to authenticated using (user_id=auth.uid() or public.is_admin()) with check (user_id=auth.uid() or public.is_admin());
create policy request_comments_delete_own on public.request_comments for delete to authenticated using (user_id=auth.uid() or public.is_admin());

-- Storage buckets
insert into storage.buckets(id,name,public) values ('avatars','avatars',true) on conflict (id) do nothing;
insert into storage.buckets(id,name,public) values ('request-files','request-files',false) on conflict (id) do nothing;

create policy avatars_read on storage.objects for select to public using (bucket_id='avatars');
create policy avatars_insert_own on storage.objects for insert to authenticated with check (bucket_id='avatars' and (storage.foldername(name))[1]=auth.uid()::text);
create policy avatars_update_own on storage.objects for update to authenticated using (bucket_id='avatars' and (storage.foldername(name))[1]=auth.uid()::text) with check (bucket_id='avatars' and (storage.foldername(name))[1]=auth.uid()::text);
create policy avatars_delete_own on storage.objects for delete to authenticated using (bucket_id='avatars' and (storage.foldername(name))[1]=auth.uid()::text);

create policy request_files_insert on storage.objects for insert to authenticated with check (bucket_id='request-files' and (storage.foldername(name))[1]=auth.uid()::text);
create policy request_files_select on storage.objects for select to authenticated using (
  bucket_id='request-files' and exists(
    select 1 from public.requests r
    where r.file_path=name and (r.visibility='public' or r.user_id=auth.uid() or public.is_admin())
  )
);
create policy request_files_delete on storage.objects for delete to authenticated using (
  bucket_id='request-files' and ((storage.foldername(name))[1]=auth.uid()::text or public.is_admin())
);

-- Public profile display fields are intentionally readable so comments/request cards can show username and avatar.
-- The app only uses username/display_name/avatar_url; keep other profile fields minimal in production.
create policy profiles_public_read on public.profiles for select to anon,authenticated using (true);

create or replace function public.current_user_role()
returns public.user_role
language sql
stable
security definer set search_path=public
as $$ select role from public.profiles where id=auth.uid(); $$;
grant execute on function public.current_user_role() to authenticated;

drop policy if exists profiles_update_self on public.profiles;
create policy profiles_update_self on public.profiles for update to authenticated
using (id=auth.uid())
with check (id=auth.uid() and role=public.current_user_role());

create policy requests_public_select_anon on public.requests for select to anon using (visibility='public');
create policy request_supports_select_anon on public.request_supports for select to anon using (exists(select 1 from public.requests r where r.id=request_id and r.visibility='public'));
create policy request_comments_select_anon on public.request_comments for select to anon using (exists(select 1 from public.requests r where r.id=request_id and r.visibility='public'));
