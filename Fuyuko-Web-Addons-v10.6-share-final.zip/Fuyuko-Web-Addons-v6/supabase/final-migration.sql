-- Fuyuko Web Addons FINAL migration
-- Jalankan SETELAH schema.sql yang sekarang sudah ada.
-- Migration ini aman dijalankan ulang: policy lama di-drop terlebih dahulu.

create extension if not exists pgcrypto;

do $$ begin
  create type public.bug_report_status as enum ('pending','in_progress','resolved','rejected');
exception when duplicate_object then null; end $$;

create table if not exists public.bug_reports (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 120),
  category text not null default 'Website',
  description text not null check (char_length(description) between 1 and 5000),
  screenshot_path text,
  screenshot_name text,
  status public.bug_report_status not null default 'pending',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.site_settings (
  id integer primary key check (id=1),
  donation_url text not null default '',
  updated_at timestamptz not null default now()
);
insert into public.site_settings(id,donation_url) values(1,'') on conflict(id) do nothing;

create table if not exists public.donations (
  id uuid primary key default gen_random_uuid(),
  donor_name text not null,
  amount numeric(14,2),
  source text not null default 'Saweria',
  note text,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);

create index if not exists idx_bug_reports_user on public.bug_reports(user_id,created_at desc);
create index if not exists idx_bug_reports_status on public.bug_reports(status,created_at desc);
create index if not exists idx_donations_created on public.donations(created_at desc);

insert into storage.buckets(id,name,public) values ('addon-images','addon-images',true) on conflict(id) do nothing;
insert into storage.buckets(id,name,public) values ('addon-files','addon-files',true) on conflict(id) do nothing;
insert into storage.buckets(id,name,public) values ('bug-reports','bug-reports',false) on conflict(id) do nothing;
update storage.buckets set public=true where id in ('addon-images','addon-files');
update storage.buckets set public=false where id='bug-reports';

-- Existing profiles query issues are avoided in the frontend by fetching profiles separately.

alter table public.bug_reports enable row level security;
alter table public.site_settings enable row level security;
alter table public.donations enable row level security;

-- Drop/recreate policies so rerunning this migration does not trigger 42710.
do $$ declare p text; begin
  foreach p in array array[
    'bug_reports_select_own','bug_reports_insert_own','bug_reports_update_own','bug_reports_delete_own','bug_reports_select_admin','bug_reports_update_admin','bug_reports_delete_admin',
    'site_settings_public_select','site_settings_admin_upsert','site_settings_admin_update',
    'donations_admin_select','donations_admin_insert','donations_admin_delete',
    'addon_images_public_read','addon_images_admin_insert','addon_images_admin_update','addon_images_admin_delete',
    'addon_files_public_read','addon_files_admin_insert','addon_files_admin_update','addon_files_admin_delete',
    'bug_reports_storage_insert_own','bug_reports_storage_select_own_or_admin','bug_reports_storage_update_own','bug_reports_storage_delete_own_or_admin'
  ] loop
    execute 'drop policy if exists '||p||' on public.bug_reports';
    execute 'drop policy if exists '||p||' on public.site_settings';
    execute 'drop policy if exists '||p||' on public.donations';
    execute 'drop policy if exists '||p||' on storage.objects';
  end loop;
end $$;

create policy bug_reports_select_own on public.bug_reports for select to authenticated using (user_id=auth.uid());
create policy bug_reports_select_admin on public.bug_reports for select to authenticated using (public.is_admin());
create policy bug_reports_insert_own on public.bug_reports for insert to authenticated with check (user_id=auth.uid());
create policy bug_reports_update_own on public.bug_reports for update to authenticated using (user_id=auth.uid()) with check (user_id=auth.uid());
create policy bug_reports_update_admin on public.bug_reports for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy bug_reports_delete_own on public.bug_reports for delete to authenticated using (user_id=auth.uid());
create policy bug_reports_delete_admin on public.bug_reports for delete to authenticated using (public.is_admin());

create policy site_settings_public_select on public.site_settings for select to anon,authenticated using (true);
create policy site_settings_admin_upsert on public.site_settings for insert to authenticated with check (public.is_admin());
create policy site_settings_admin_update on public.site_settings for update to authenticated using (public.is_admin()) with check (public.is_admin());

create policy donations_admin_select on public.donations for select to authenticated using (public.is_admin());
create policy donations_admin_insert on public.donations for insert to authenticated with check (public.is_admin());
create policy donations_admin_delete on public.donations for delete to authenticated using (public.is_admin());

-- Addon storage
create policy addon_images_public_read on storage.objects for select to public using (bucket_id='addon-images');
create policy addon_images_admin_insert on storage.objects for insert to authenticated with check (bucket_id='addon-images' and public.is_admin());
create policy addon_images_admin_update on storage.objects for update to authenticated using (bucket_id='addon-images' and public.is_admin()) with check (bucket_id='addon-images' and public.is_admin());
create policy addon_images_admin_delete on storage.objects for delete to authenticated using (bucket_id='addon-images' and public.is_admin());

create policy addon_files_public_read on storage.objects for select to public using (bucket_id='addon-files');
create policy addon_files_admin_insert on storage.objects for insert to authenticated with check (bucket_id='addon-files' and public.is_admin());
create policy addon_files_admin_update on storage.objects for update to authenticated using (bucket_id='addon-files' and public.is_admin()) with check (bucket_id='addon-files' and public.is_admin());
create policy addon_files_admin_delete on storage.objects for delete to authenticated using (bucket_id='addon-files' and public.is_admin());

-- Bug screenshot storage
create policy bug_reports_storage_insert_own on storage.objects for insert to authenticated with check (bucket_id='bug-reports' and (storage.foldername(name))[1]=auth.uid()::text);
create policy bug_reports_storage_select_own_or_admin on storage.objects for select to authenticated using (bucket_id='bug-reports' and ((storage.foldername(name))[1]=auth.uid()::text or public.is_admin()));
create policy bug_reports_storage_update_own on storage.objects for update to authenticated using (bucket_id='bug-reports' and (storage.foldername(name))[1]=auth.uid()::text) with check (bucket_id='bug-reports' and (storage.foldername(name))[1]=auth.uid()::text);
create policy bug_reports_storage_delete_own_or_admin on storage.objects for delete to authenticated using (bucket_id='bug-reports' and ((storage.foldername(name))[1]=auth.uid()::text or public.is_admin()));

-- Safety: only admin can manage donation records, and public can only see the donation link setting.

-- Prevent normal users from changing moderation status fields directly.
create or replace function public.protect_moderation_status()
returns trigger
language plpgsql
security definer set search_path=public
as $$
begin
  if not public.is_admin() then
    if tg_table_name='requests' then
      new.status := old.status;
    elsif tg_table_name='bug_reports' then
      new.status := old.status;
    end if;
  end if;
  return new;
end;
$$;

drop trigger if exists protect_request_status on public.requests;
create trigger protect_request_status
before update on public.requests
for each row execute procedure public.protect_moderation_status();

drop trigger if exists protect_bug_status on public.bug_reports;
create trigger protect_bug_status
before update on public.bug_reports
for each row execute procedure public.protect_moderation_status();


-- Download method for addon releases.
-- Existing releases remain Download here by default.
alter table public.addon_releases add column if not exists file_name text;
alter table public.addon_releases add column if not exists download_mode text not null default 'download_here';
alter table public.addon_releases add column if not exists download_url text;

do $$ begin
  alter table public.addon_releases drop constraint if exists addon_releases_download_mode_check;
  alter table public.addon_releases add constraint addon_releases_download_mode_check check (download_mode in ('download_here','external_link'));
exception when duplicate_object then null; end $$;

update public.addon_releases
set file_name = coalesce(file_name, nullif(reverse(split_part(reverse(file_path), '/', 1)), ''))
where file_path is not null and file_path <> '' and (file_name is null or file_name='');
