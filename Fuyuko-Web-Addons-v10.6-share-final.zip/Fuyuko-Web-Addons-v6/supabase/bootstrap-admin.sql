-- 1) Daftar dulu lewat website menggunakan username yang kamu pilih untuk admin.
-- 2) Setelah akun berhasil dibuat, jalankan query ini sekali untuk menjadikannya admin.
-- Ganti username sesuai akun admin kamu.

update public.profiles
set role='admin', updated_at=now()
where username='HarsanAdmin1';
